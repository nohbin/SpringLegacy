package org.zerock.sample;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class Chef {
	
}
