package com.bigmoney.testproject.dao;

import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDao {
	@Autowired
	SqlSessionTemplate sqlsessionTemplate;
	
	public int insert(Map<String, Object> map) {
		
		return sqlsessionTemplate.insert("member.insert", map);
	}

	public boolean join(Map<String, Object> map) {
		// TODO Auto-generated method stub
		Map<String, Object> result = sqlsessionTemplate.selectOne("member.getmember", map);
		return result != null;
	}
}
