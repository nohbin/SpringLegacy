package com.bigmoney.testproject.service;

import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bigmoney.testproject.dao.MemberDao;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberDao memberDao;
	
	@Override
	public String join(Map<String, Object> map) {
		// TODO Auto-generated method stub
		memberDao.insert(map);
		return null;
	}

	@Override
	public boolean login(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return memberDao.join(map);
	}
	
	
	
	
}
