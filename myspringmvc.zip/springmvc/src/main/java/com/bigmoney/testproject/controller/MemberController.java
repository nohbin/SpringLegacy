package com.bigmoney.testproject.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bigmoney.testproject.service.MemberService;

@Controller
public class MemberController {

	@Autowired
	MemberService memberService;
	
	
	@GetMapping(value = "/login")
	public ModelAndView joinForm() {
		return new ModelAndView("member/login");
	}
	
	@PostMapping(value = "/login")
	@ResponseBody
	public String login(@RequestParam Map<String, Object> map , HttpServletRequest req) throws Exception {
		HttpSession session = req.getSession();
		boolean isMemeber = memberService.login(map);
		if(isMemeber) {
			session.setAttribute("email", map.get("email"));
			return "good";
		}else {
		}
		throw new Exception("로그인 실패");
	}
	
	@PostMapping("/logout")
	@ResponseBody
	public String logout(HttpServletRequest req) {
		
		HttpSession session = req.getSession(false);
		session.invalidate();
		
		return "success"; //메인으로 보내기
	}
	
	@PostMapping(value = "/join")
	public ModelAndView join(@RequestParam Map<String, Object> map) {
		
		ModelAndView mv = new ModelAndView();
		
		String id = memberService.join(map);
		if(id == null)
			mv.setViewName("redirect:/join");
		else
			mv.setViewName("redirect:/home");
		return mv;
	}
	
}
