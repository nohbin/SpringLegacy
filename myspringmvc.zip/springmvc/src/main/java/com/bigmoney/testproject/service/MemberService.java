package com.bigmoney.testproject.service;

import java.util.Map;


public interface MemberService {

	String join(Map<String, Object> map);

	boolean login(Map<String, Object> map);

}
